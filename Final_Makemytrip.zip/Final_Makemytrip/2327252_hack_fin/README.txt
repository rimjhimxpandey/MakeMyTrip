
Project Name: BOOKING OUSTATION CABS
----------------------------------------------------------------------------------------------------------------------------------------------------
 
Problem Statement: Book one way outstation cab and display the lowest charges
 

1. From Delhi to Manali, himachal Pradesh.
2. Pick up from Delhi at 6.30 AM on 23rd Dec 2019
3. Car type should be SUV.
(Suggested Site: Makemytrip however  you are free to choose any other legitimate  site)
----------------------------------------------------------------------------------------------------------------------------------------------------
 
Detailed Description: Main Project
 
1. Book one way outstation cab, From Delhi to Manali, himachal Pradesh, give future date & time & Car type should be SUV; Display the lowest charges
2. Find Group Gifting in Gift Cards, fill card details & give invalid email; capture & display the error message
3. On the Hotel booking page, extract all the numbers for Adult persons and store in a List; Display the same
(Suggested Site: makemytrip.com however  you are free to choose any other legitimate site)
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
Key Automation Scope

Handling alerts
Filling simple form, Capture warning message
Scrolling down in web page
Extract drop down items & store in collections
Navigation from Menus
Navigating back to home page
----------------------------------------------------------------------------------------------------------------------------------------------------
 
Output: 

==================

[INFO] Scanning for projects...
[INFO] 
[INFO] [1m-------------------< [0;36mhackathon_vish:hackathon_vish[0;1m >--------------------[m
[INFO] [1mBuilding hackathon_project 0.0.1-SNAPSHOT[m
[INFO]   from pom.xml
[INFO] [1m--------------------------------[ jar ]---------------------------------[m
[INFO] 
[INFO] [1m--- [0;32mresources:3.3.1:resources[m [1m(default-resources)[m @ [36mhackathon_vish[0;1m ---[m
[WARNING] Using platform encoding (UTF-8 actually) to copy filtered resources, i.e. build is platform dependent!
[INFO] Copying 0 resource from src\main\resources to target\classes
[INFO] 
[INFO] [1m--- [0;32mcompiler:3.11.0:compile[m [1m(default-compile)[m @ [36mhackathon_vish[0;1m ---[m
[INFO] Nothing to compile - all classes are up to date
[INFO] 
[INFO] [1m--- [0;32mresources:3.3.1:testResources[m [1m(default-testResources)[m @ [36mhackathon_vish[0;1m ---[m
[WARNING] Using platform encoding (UTF-8 actually) to copy filtered resources, i.e. build is platform dependent!
[INFO] Copying 4 resources from src\test\resources to target\test-classes
[INFO] 
[INFO] [1m--- [0;32mcompiler:3.11.0:testCompile[m [1m(default-testCompile)[m @ [36mhackathon_vish[0;1m ---[m
[INFO] Nothing to compile - all classes are up to date
[INFO] 
[INFO] [1m--- [0;32msurefire:3.2.5:test[m [1m(default-test)[m @ [36mhackathon_vish[0;1m ---[m
[INFO] Using auto detected provider org.apache.maven.surefire.testng.TestNGProvider
[INFO] 
[INFO] -------------------------------------------------------
[INFO]  T E S T S
[INFO] -------------------------------------------------------
[INFO] Running [1mTestSuite[m
SLF4J: Failed to load class "org.slf4j.impl.StaticLoggerBinder".
SLF4J: Defaulting to no-operation (NOP) logger implementation
SLF4J: See http://www.slf4j.org/codes.html#StaticLoggerBinder for further details.

Scenario: Trying to handle popups in make my trip page           [90m# Features/01Popup.feature:5[0m
MakeMyTrip - #1 Travel Website 50% OFF on Hotels, Flights & Holiday
Launching the webpage and checking for popups
  [32mGiven [0m[32mMake my trip website is being launched and popup appears[0m [90m# stepDefinitions.handlePopup.make_my_trip_website_is_being_launched_and_popup_appears()[0m

    Embedding Trying to handle popups in make my trip page [image/png 560491 bytes]

no such element: Unable to locate element: {"method":"xpath","selector":"//*[@id='webklipper-publisher-widget-container-notification-frame']"}
  (Session info: chrome=121.0.6167.86)
For documentation on this error, please visit: https://www.selenium.dev/documentation/webdriver/troubleshooting/errors#no-such-element-exception
Build info: version: '4.18.1', revision: 'b1d3319b48'
System info: os.name: 'Windows 11', os.arch: 'amd64', os.version: '10.0', java.version: '22'
Driver info: org.openqa.selenium.chrome.ChromeDriver
Command: [90f0257f3e2ee2841eac9dfd55c052fc, findElement {value=//*[@id='webklipper-publisher-widget-container-notification-frame'], using=xpath}]
Capabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 121.0.6167.86, chrome: {chromedriverVersion: 121.0.6167.184 (057a8ae7deb..., userDataDir: C:\Windows\SystemTemp\scope...}, fedcm:accounts: true, goog:chromeOptions: {debuggerAddress: localhost:64912}, networkConnectionEnabled: false, pageLoadStrategy: normal, platformName: windows, proxy: Proxy(), se:cdp: ws://localhost:64912/devtoo..., se:cdpVersion: 121.0.6167.86, setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify, webauthn:extension:credBlob: true, webauthn:extension:largeBlob: true, webauthn:extension:minPinLength: true, webauthn:extension:prf: true, webauthn:virtualAuthenticators: true}
Session ID: 90f0257f3e2ee2841eac9dfd55c052fc
  [32mWhen [0m[32mTry to close the popup[0m                                    [90m# stepDefinitions.handlePopup.try_to_close_the_popup()[0m

    Embedding Trying to handle popups in make my trip page [image/png 342903 bytes]

If popup appears it has been closed
  [32mThen [0m[32mpopup is closed successfully[0m                              [90m# stepDefinitions.handlePopup.popup_is_closed_successfully()[0m

    Embedding Trying to handle popups in make my trip page [image/png 342903 bytes]


Scenario: book a cab                 [90m# Features/02bookoneway.feature:5[0m
The make my trip home page is loaded after popup handling
Cab book page is loaded
  [32mGiven [0m[32mmakeMytrip webpage loaded[0m    [90m# stepDefinitions.bookOneWayTrip.make_mytrip_webpage_loaded()[0m

    Embedding book a cab [image/png 485672 bytes]

Delhi, India
  [32mWhen [0m[32mTo enter the from To location[0m [90m# stepDefinitions.bookOneWayTrip.to_enter_the_from_To_location()[0m

    Embedding book a cab [image/png 318970 bytes]

  [32mAnd [0m[32mTo enter the From date[0m         [90m# stepDefinitions.bookOneWayTrip.to_enter_the_from_date()[0m

    Embedding book a cab [image/png 318212 bytes]

  [32mThen [0m[32mClick on the search[0m           [90m# stepDefinitions.bookOneWayTrip.click_on_the_search()[0m

    Embedding book a cab [image/png 253017 bytes]


Scenario: Fetch lowest SUV price                               [90m# Features/03suvSelect.feature:4[0m
The list of cars for hire is displayed
  [32mGiven [0m[32mCab List page for given search conditions is displayed[0m [90m# stepDefinitions.fetchSuvprice.cab_list_page_for_given_search_conditions_is_displayed()[0m

    Embedding Fetch lowest SUV price [image/png 253017 bytes]

  [32mWhen [0m[32mSelect SUV and display prices[0m                           [90m# stepDefinitions.fetchSuvprice.select_suv_and_display_prices()[0m

    Embedding Fetch lowest SUV price [image/png 259347 bytes]

Car Names	Prices
----------	--------
Xylo, Ertiga	₹ 9,720
Toyota Innova	₹ 13,162
Xylo, Ertiga	₹ 14,560
Innova Crysta	₹ 16,280
------------------------
Lowest Price in the above list
-------------------------------
Xylo, Ertiga	₹ 9,720
  [32mThen [0m[32mLowest price is fetched[0m                                 [90m# stepDefinitions.fetchSuvprice.lowest_price_is_fetched()[0m

    Embedding Fetch lowest SUV price [image/png 259966 bytes]


Scenario: To give invalid input to giftcard and fetch error message [90m# Features/04giftCard.feature:4[0m
  [32mGiven [0m[32mNavigate to the Gift card menu[0m                              [90m# stepDefinitions.giftCardsFetchError.navigate_to_the_gift_card_menu()[0m

    Embedding To give invalid input to giftcard and fetch error message [image/png 128664 bytes]

  [32mWhen [0m[32mclick on gift card[0m                                           [90m# stepDefinitions.giftCardsFetchError.click_on_gift_card()[0m

    Embedding To give invalid input to giftcard and fetch error message [image/png 106022 bytes]

Number of rows:0
Number of cells:3

Please enter a valid Email id.
  [32mAnd [0m[32mfill the invalid details[0m                                      [90m# stepDefinitions.giftCardsFetchError.fill_the_invalid_details()[0m

    Embedding To give invalid input to giftcard and fetch error message [image/png 114600 bytes]

The lowest cost price of SUV is fetched and printed
  [32mThen [0m[32mError message is displayed[0m                                   [90m# stepDefinitions.giftCardsFetchError.error_message_is_displayed()[0m

    Embedding To give invalid input to giftcard and fetch error message [image/png 114600 bytes]


Scenario: To fetch Adult persons list in hotel booking [90m# Features/05Adultlist.feature:5[0m
  [32mGiven [0m[32mNavigate to hotel booking[0m                      [90m# stepDefinitions.Hotel_Adult.navigate_to_hotel_booking()[0m

    Embedding To fetch Adult persons list in hotel booking [image/png 435721 bytes]

The list of number of adults allowed:
01
02
03
04
05
06
07
08
09
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
  [32mWhen [0m[32mfetch adult list[0m                                [90m# stepDefinitions.Hotel_Adult.fetch_adult_list()[0m

    Embedding To fetch Adult persons list in hotel booking [image/png 414026 bytes]

The list is fetched and displayed
  [32mThen [0m[32mAdult list is displayed[0m                         [90m# stepDefinitions.Hotel_Adult.adult_list_is_displayed()[0m

    Embedding To fetch Adult persons list in hotel booking [image/png 414026 bytes]

no such element: Unable to locate element: {"method":"xpath","selector":"//*[@id='webklipper-publisher-widget-container-notification-frame']"}
  (Session info: chrome=121.0.6167.86)
For documentation on this error, please visit: https://www.selenium.dev/documentation/webdriver/troubleshooting/errors#no-such-element-exception
Build info: version: '4.18.1', revision: 'b1d3319b48'
System info: os.name: 'Windows 11', os.arch: 'amd64', os.version: '10.0', java.version: '22'
Driver info: org.openqa.selenium.chrome.ChromeDriver
Command: [e52e56ae385b5560fffc3b434a6eacbe, findElement {value=//*[@id='webklipper-publisher-widget-container-notification-frame'], using=xpath}]
Capabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 121.0.6167.86, chrome: {chromedriverVersion: 121.0.6167.184 (057a8ae7deb..., userDataDir: C:\Windows\SystemTemp\scope...}, fedcm:accounts: true, goog:chromeOptions: {debuggerAddress: localhost:65165}, networkConnectionEnabled: false, pageLoadStrategy: normal, platformName: windows, proxy: Proxy(), se:cdp: ws://localhost:65165/devtoo..., se:cdpVersion: 121.0.6167.86, setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify, webauthn:extension:credBlob: true, webauthn:extension:largeBlob: true, webauthn:extension:minPinLength: true, webauthn:extension:prf: true, webauthn:virtualAuthenticators: true}
Session ID: e52e56ae385b5560fffc3b434a6eacbe
Delhi, India
Car Names	Prices
----------	--------
Xylo, Ertiga	₹ 8,607
Toyota Innova	₹ 12,912
Xylo, Ertiga	₹ 14,560
Innova Crysta	₹ 16,280
------------------------
Lowest Price in the above list
-------------------------------
Xylo, Ertiga	₹ 8,607
Number of rows:0
Number of cells:3

Please enter a valid Email id.
The list of number of adults allowed:
01
02
03
04
05
06
07
08
09
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
[INFO] [1;32mTests run: [0;1;32m16[m, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 269.7 s -- in [1mTestSuite[m
[INFO] 
[INFO] Results:
[INFO] 
[INFO] [1;32mTests run: 16, Failures: 0, Errors: 0, Skipped: 0[m
[INFO] 
[INFO] [1m------------------------------------------------------------------------[m
[INFO] [1;32mBUILD SUCCESS[m
[INFO] [1m------------------------------------------------------------------------[m
[INFO] Total time:  04:34 min
[INFO] Finished at: 2024-04-19T10:10:41+05:30
[INFO] [1m------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------------
 
Dependencies and Plugins:
 
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
  <modelVersion>4.0.0</modelVersion>
  <groupId>hackathon_vish</groupId>
  <artifactId>hackathon_vish</artifactId>
  <version>0.0.1-SNAPSHOT</version>
  <name>hackathon_project</name>
  <build>
<plugins>
<plugin>
<groupId>org.apache.maven.plugins</groupId>
<artifactId>maven-surefire-plugin</artifactId>
<version>3.2.5</version>
<configuration>
<suiteXmlFiles>
<suiteXmlFile>testngcucu.xml</suiteXmlFile>
<suiteXmlFile>testng.xml</suiteXmlFile>
</suiteXmlFiles>
</configuration>
</plugin>
</plugins>
</build>
<dependencies>
  <!-- https://mvnrepository.com/artifact/org.testng/testng -->
<dependency>
    <groupId>org.testng</groupId>
    <artifactId>testng</artifactId>
    <version>7.9.0</version>
    <scope>test</scope>
</dependency>
<!-- https://mvnrepository.com/artifact/org.seleniumhq.selenium/selenium-java -->
<dependency>
    <groupId>org.seleniumhq.selenium</groupId>
    <artifactId>selenium-java</artifactId>
    <version>4.18.1</version>
</dependency>
 
  <!-- https://mvnrepository.com/artifact/io.cucumber/cucumber-java  -->    
    <dependency>
		    <groupId>io.cucumber</groupId>
		    <artifactId>cucumber-java</artifactId>
		    <version>7.14.1</version>
		</dependency>
 
 
       <!-- https://mvnrepository.com/artifact/io.cucumber/cucumber-junit -->
	
<!-- https://mvnrepository.com/artifact/commons-io/commons-io -->
<dependency>
    <groupId>commons-io</groupId>
    <artifactId>commons-io</artifactId>
    <version>2.15.1</version>
</dependency>
 
	<dependency>
		    <groupId>io.cucumber</groupId>
		    <artifactId>cucumber-junit</artifactId>
		    <version>7.14.1</version>
		    <scope>test</scope>
		</dependency>
 
	<!-- https://mvnrepository.com/artifact/io.cucumber/cucumber-testng -->
		<dependency>
			<groupId>io.cucumber</groupId>
			<artifactId>cucumber-testng</artifactId>
			<version>7.15.0</version>
		</dependency>
		
			<!-- https://mvnrepository.com/artifact/tech.grasshopper/extentreports-cucumber7-adapter -->
	<!-- https://mvnrepository.com/artifact/ru.yandex.qatools.ashot/ashot -->
		<dependency>
		<groupId>ru.yandex.qatools.ashot</groupId>
		<artifactId>ashot</artifactId>
		<version>1.5.4</version>
		</dependency>
		  <dependency>
<groupId>com.aventstack</groupId>
<artifactId>extentreports</artifactId>
<version>5.1.1</version>
</dependency>
<!-- https://mvnrepository.com/artifact/com.aventstack/extentreports-cucumber4-adapter -->
		<dependency>
		<groupId>tech.grasshopper</groupId>
		<artifactId>extentreports-cucumber7-adapter</artifactId>
		<version>1.14.0</version>
		</dependency>
		
		
		<!-- https://mvnrepository.com/artifact/org.apache.logging.log4j/log4j-core -->
		<dependency>
			<groupId>org.apache.logging.log4j</groupId>
			<artifactId>log4j-core</artifactId>
			<version>2.22.1</version>
		</dependency>
 
		<!-- https://mvnrepository.com/artifact/org.apache.logging.log4j/log4j-api -->
		<dependency>
			<groupId>org.apache.logging.log4j</groupId>
			<artifactId>log4j-api</artifactId>
			<version>2.22.1</version>
		</dependency>
		
	
<!-- https://mvnrepository.com/artifact/com.relevantcodes/extentreports -->
 
<!-- https://mvnrepository.com/artifact/org.freemarker/freemarker -->
 
 
  </dependencies>
</project>


----------------------------------------------------------------------------------------------------------------------------------------------------